/*app.js*/
var mysqlDB = require('./mysql-db');
mysqlDB.connect();

/*source*/